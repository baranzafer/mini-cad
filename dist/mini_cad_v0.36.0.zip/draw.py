"""Çizim aracı: 3D görünüm içinde kayan bir araç penceresiyle tel kafese çizer.

Araçlar   Seç (W) · Doğru (L) · Teğet yay (A) · 3 noktalı yay (E) · Merkezli yay (M, D: yön) ·
          Daire (O) · Dikdörtgen (R) · Spline: kontrol noktalı (S) · noktalardan geçen (K) ·
          Kalem (P) · Q: son iki araç arasında geçiş · Shift+Q: düzlem seç
Oluştur+  Dikdörtgen: 3 nokta / merkezden / 3 nokta merkezden (R'ye tekrar bas) · Çokgen ·
          Kanal: merkezden merkeze / toplam boy / merkez noktalı / 3 noktalı yay · Elips ·
          Teğet daire (O'ya tekrar bas) · Nokta · Yansıt (bkz. draw_shapes.py)
Değiştir  Kırp (B, Shift: Uzat) · Uzat · Böl · Ötele · Köşe yuvarla · Pah (taslak üzerinde;
          bkz. draw_modify.py)
Düzenle   Taşı · Kopyala · Döndür · Ölçekle · Esnet · Desen: dikdörtgen, dairesel · Ayna
          (seç → temel nokta → hedef; bkz. draw_xform.py)
Düzlem    Oto · XY · XZ · YZ · Görünüş (X / Y / Z / V tuşları)
Kısıtlar  Eksen · Paralel · Dik · Doğrusal · Eşit · Çakışık · Sabit · Teğet · Simetrik ·
          Uzunluk · Açı (pencereden seç, sonra kenar / noktalara tıkla)

  Sol tık           nokta koy          Sağ tık / Enter   çizgiyi bitir: TASLAĞA eklenir
  Ctrl+Enter        Bitir: taslaktaki bütün çizgiler eğri objesine kaydedilir (hedef:
                    mevcut eğri ya da yeni eğri; pencerede seçilir)
  Taslak düzenleme  taslağın noktalarını ve eğri tutamaçlarını sürükle; X/Y/Z eksen kilidi
                    (3. eksende düzenleme); pürüzsüz birleşimde karşı tutamaç hizalı kalır.
                    Tıklanan noktada pivot çıkar; oklarından sürükleyince o eksende taşınır.
                    Sürüklerken uç / orta / merkez, kılavuzlar ve ızgara yakalaması geçerli;
                    ölçü yardımcısı uzunluk / açıyı gösterir, yazarak değer girilir (Tab).
  Ctrl+Z / Ctrl+Shift+Z  taslak aşamasında geri al / yinele (Bitir'den sonra Blender'ınki)
  T                 iz: referans noktadan eksenler boyunca (ölçü yazarak) başlangıç noktası
  Düzlem seçimi     1/2 yön (eksen düzlemi ya da yüz), 2/2 yükseklik (fare / nokta / yazarak)
  G                 geçici zemin: ızgaranın yönünü / yüksekliğini değiştir (sağ tık: yön aynı,
                    sadece yükseklik); tekrar U'ya basılana kadar yeni çizgiler bu zemine
                    çizilir, sonra asıl düzleme dönülür. Shift+G: başka bir geçici zemin
  Rakam yaz         ölçü; Tab ile sonraki alan; Enter ile noktayı koy (ör. 25mm, 30)
  C                 başlangıca dönüp kapat      F  kapalı çizgiden yüzey (Ctrl+F: yeni gövde)
  Shift             15° adımlar        Ctrl  yakalamayı kapat        Backspace  geri al
  Kısıt simgesi     sağ tık: dondur / sil (simgeler bilerek silik çizilir)
  Esc               duraklat: "Seç" aracına geçer, tıklamalar Blender'a gider; ikinci Esc kapatır

Yakalama: tel kafes ve CAD gövdesi kenarlarının ucu, ortası, çember merkezi, kesişim ve
kenar üzerinde en yakın nokta, yay merkezleri. Sezgisel kılavuzlar (FORGE snap_math):
yatay / dikey, mevcut doğrulara paralel / dik, önceki parçanın devamı, uç / orta / merkez
noktalarıyla hiza, doğru uzantısı, eğri ve yay uçlarından teğet uzantı, yayın çemberi
boyunca devam. Hepsi zayıf mıknatıstır; çizimi engellemez (Ctrl ile kapanır).
"Oto kısıt" açıksa yakalanan yatay/dikey, paralel/dik, uç çakışması ve yazılan uzunluk
kısıt olarak kaydedilir.

Çizilen her çizgi / şekil eğri objesine YENİ bir spline olarak eklenir; var olan
spline'ların sırası değişmez, böylece yüzeylerin kenar referansları bozulmaz.
"""

import copy
import math
import traceback
import blf
import bpy
import gpu
import numpy as np
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from . import constraints, core, palette, ribbon_state
from . import drawmath as dm

# Ortak adlar draw_common'da; burada geriye dönük uyum için yeniden dışa aktarılır.
from .draw_common import (
    AXIS_COLS, AXIS_OF, CHAIN_TOOLS, COL_ACTIVE, COL_BOX, COL_DONE, COL_GRID, COL_GUIDE,
    COL_REF, COL_RUBBER, COL_SNAP, COL_TEXT, COL_U, COL_V, FIELDS, GRID_MIN_PX, GRID_PX,
    GUIDE_PX, MODIFIERS, PASS_KEYS, PLANE_COLS, PRIORITY, REF_PX, SHAPE_TOOLS, SNAP_PX,
    TOOL_KEYS, _HANDLES, _LAST, _Refs, _STATE, _UNIT_SUFFIX, _axis_col, _bezier, _dashed,
    _line_thirds, _marker, _move_handle, _move_node, _poly, _project, _rect, _remove_handle,
    _seg_px_dist, _shader, _text, cleanup_all, is_running, parse_angle, parse_length,
    save_sketch,
)
from .draw_plane import PlaneMixin
from .draw_snap import SnapMixin
from .draw_sketch import SketchMixin
from .draw_edit import EditMixin
from .draw_junction import JunctionMixin
from .draw_glyphs import ConstraintUIMixin
from .draw_render import RenderMixin
from .draw_modify import MOD_HELP, ModifyMixin
from .draw_xform import TransformMixin
from .draw_shapes import PICK_HELP, SHAPE_NAMES, STEPS, ShapeMixin
from .draw_dims import DimMixin
from .draw_text import TextMixin
from .draw_skcons import SketchConsMixin
from .draw_common import CLICK_SHAPES, MODIFY_TOOLS, PICK_TOOLS, TOOL_CYCLES, XFORM_TOOLS


def _opacity_refresh(drawing):
    try:
        from . import opacity
        if getattr(bpy.context.scene, "minicad_draw_ghost", False):
            opacity.apply_all(drawing)
    except Exception:
        traceback.print_exc()


class MINICAD_OT_draw(JunctionMixin, SnapMixin, PlaneMixin, SketchMixin, EditMixin, ConstraintUIMixin, RenderMixin,
                      ModifyMixin, TransformMixin, ShapeMixin, DimMixin, TextMixin,
                      SketchConsMixin, bpy.types.Operator):
    bl_idname = "minicad.draw"

    bl_label = "Tel Kafes Çiz"

    bl_description = ("Çizim penceresini açar: doğru, yaylar, daire, dikdörtgen, spline, kalem; "
                      "çalışma düzlemi; paralel / dik / eşit / sabit gibi kısıtlar")

    bl_options = {"REGISTER", "UNDO"}

    # v0.23.0: açılışta bu eğri objesinin (çizimin) tamamı taslağa alınır (minicad.edit_sketch)
    edit_curve: bpy.props.StringProperty(name="Düzenlenecek çizim", default="",
                                         options={"HIDDEN", "SKIP_SAVE"})
    # v0.30.0: açılışta düzlem: DEFAULT = sahne ayarı (Önce düzlem), AUTO = otomatik düzlemle
    # hemen çiz, PICK = önce düzlem seçtir (Eskiz başlat)
    start_plane: bpy.props.EnumProperty(
        name="Başlangıç düzlemi", items=[("DEFAULT", "Ayar", ""), ("AUTO", "Otomatik", ""),
                                         ("PICK", "Seç", "")],
        default="DEFAULT", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == "VIEW_3D"

    # ------------------------------------------------------------ yaşam döngüsü

    def invoke(self, context, event):
        if _STATE["active"] is not None:
            cleanup_all()                      # taslak (düzenlenen çizim dahil) önce kaydedilir
            self.report({"INFO"}, "Çizim kaydedildi ve kapatıldı")
            return {"CANCELLED"}
        try:
            from . import pick
            pick.cleanup_all()                 # iki mod aynı anda çalışmasın
        except Exception:
            pass
        self.stop_request = False
        self.area = context.area
        self.region = next((r for r in self.area.regions if r.type == "WINDOW"), None)
        self.rv3d = self.area.spaces.active.region_3d
        if self.region is None or self.rv3d is None:
            self.report({"ERROR"}, "3D görünüm bulunamadı")
            return {"CANCELLED"}
        self.ui_scale = context.preferences.system.ui_scale
        self.radius = SNAP_PX * self.ui_scale
        self.sketch = []                 # Bitir'e kadar hafızada tutulan çizgiler
        self.refs = _Refs(context)
        self.dirty = False
        self.plane_mode = "AUTO"
        self.tool = "LINE"
        self.segs = []
        self.start = None
        self.plane = None
        self.tmp_plane = None
        self.cursor = None
        self.preview = []
        self.snap_kind = None
        self.snap_id = None
        self.info = None
        self.typed = ["", ""]
        self.field = 0
        self.mouse = (0.0, 0.0)
        self.shift = self.ctrl = False
        self.last_closed = None
        self.arc_info = None
        self._grp = 0
        self.stage = []
        self.shape_plane = None
        self.pen = None
        self.out_h = None
        self.carc_flip = False
        self.node_ids = {}
        self.c_refs = []
        self.c_hover = None
        self._cur_chords = []
        self.snap_on = True
        sc = context.scene
        self.grid_on = bool(getattr(sc, "minicad_grid_snap", True))
        self.locked = None
        self.hover_plane = None
        self.gmenu = None
        self.prev_tool = None
        self.start_tan = None
        self.sk_hover = None
        self.sk_drag = None
        self.jn_drag = None
        self.jn_hover = None
        self.sk_sel = None               # seçili taslak noktası / tutamacı (pivot gösterilir)
        self.hist, self.redo = [], []    # taslak aşamasının geri al / yinele geçmişi
        self._hsnap = None
        self._hsig = None
        self.track = None
        self.off = None
        self.temp = None                 # geçici zemin (G): {"saved", "plane", "label", "grid_o"}
        self.axis_lock = None            # eksen kilidi (X / Y / Z): 0 / 1 / 2
        self.snap_attach = None          # imleç bir eğrinin üstünde (Bitir'de eğriye bağlanır)
        self.attach_pts = []             # süren çizginin eğri üstüne konmuş noktaları
        self.temp_pick = None            # geçici zemin seçiliyor: {"saved"}
        self.snap_src = None             # geçici zeminde izdüşürülen yakalamanın asıl noktası
        self.snap_src_id = None
        self.plane_snap = None           # düzlem seçerken yakalanan nokta (konum, tür)
        self._mod_init()                 # değiştir araçları (draw_modify)
        self._xf_init()                  # düzenle / desen araçları (draw_xform)
        self._sh_init()                  # şekiller, nokta, teğet daire, yansıt (draw_shapes)
        self._dim_init()                 # ölçü değeri düzenleme (draw_dims)
        self._txt_init()                 # metin (draw_text)
        self._skc_init()                 # taslak kısıtları (draw_skcons)
        self.sk_cons, self.sk_pats = [], {}   # Bitir'de yazılacak kısıtlar / desen ilişkileri
        self.edit_obj = None             # tamamı taslağa alınmış çizim (Bitir'de ona yazılır)
        self.fillet_eq = None
        sp = getattr(self, "start_plane", "DEFAULT")
        if not isinstance(sp, str):
            sp = "DEFAULT"
        self.phase = "PLANE" if (sp == "PICK" or (sp == "DEFAULT" and
                                                  getattr(sc, "minicad_pick_plane", False))) \
            else "DRAW"
        self.palette = palette.Palette(self.ui_scale)
        self.created = 0
        self.msg = ""
        self._h3 = bpy.types.SpaceView3D.draw_handler_add(self._draw3d, (), "WINDOW",
                                                          "POST_VIEW")
        self._h2 = bpy.types.SpaceView3D.draw_handler_add(self._draw2d, (), "WINDOW",
                                                          "POST_PIXEL")
        _HANDLES.extend([self._h3, self._h2])
        _STATE["active"] = self
        _opacity_refresh(True)                   # v0.34.0: çizerken saydam kipi
        context.window_manager.modal_handler_add(self)
        self._status(context)
        name = getattr(self, "edit_curve", "") or ""
        if isinstance(name, str) and name:
            try:
                self._edit_load_all(context, name)
            except Exception:
                traceback.print_exc()
        self.area.tag_redraw()
        return {"RUNNING_MODAL"}

    def _finish(self, context):
        for h in (getattr(self, "_h3", None), getattr(self, "_h2", None)):
            if h is not None:
                _remove_handle(h)
        self._h3 = self._h2 = None
        if _STATE["active"] is self:
            _STATE["active"] = None
            _opacity_refresh(False)
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        try:
            self.area.tag_redraw()
        except Exception:
            pass

    def _tool_name(self):
        if self.tool.startswith("C_"):
            return "Kısıt: " + next((n for k, n in palette.CONSTRAINTS
                                     if k == self.tool[2:]), self.tool)
        return next((n.split(":")[0] for k, n, _ in palette.DRAW_TOOLS + palette.MODIFY_TOOLS +
                     palette.XFORM_TOOLS + palette.PATTERN_TOOLS if k == self.tool), self.tool)

    def _status(self, context, msg=None):
        if msg is not None:
            self.msg = msg
        plane = "Otomatik" if self.plane_mode == "AUTO" else dm.PLANE_LABELS[self.plane_mode]
        if self.plane is not None:
            plane += f" → {dm.PLANE_LABELS.get(self.plane.name, self.plane.name)}"
        if self.phase == "OFFSET":
            txt = ("DÜZLEM YÜKSEKLİĞİ: fareyi normal boyunca gezdir (noktalara / ızgaraya "
                   "yapışır) ya da değer yaz · Tık / Enter: onayla · Sağ tık: sıfır · "
                   "Esc: yöne geri dön")
            try:
                context.workspace.status_text_set(txt)
            except Exception:
                pass
            return
        if self.phase == "PLANE" and getattr(self, "temp_pick", None) is not None:
            txt = ("GEÇİCİ ZEMİN (1/2: yön): eksen düzlemine ya da gövde yüzüne tıkla  |  X/Y/Z/V: "
                   "eksen / görünüş düzlemi  |  Noktaya tık: o noktadan geçen zemin  |  Sağ tık / Enter: "
                   "mevcut yön, sadece yükseklik  |  Esc: iptal")
            try:
                context.workspace.status_text_set(txt)
            except Exception:
                pass
            return
        if self.phase == "PLANE":
            txt = ("ÇİZİM DÜZLEMİNİ SEÇ (1/2: yön): eksen düzlemine ya da gövde yüzüne tıkla  |  X/Y/Z/V: "
                   "eksen / görünüş düzlemi  |  Sağ tık / Enter: atla (otomatik)  |  Esc: çık")
            if self.msg:
                txt = f"{self.msg}   —   {txt}"
            try:
                context.workspace.status_text_set(txt)
            except Exception:
                pass
            return
        if self.tool == "SELECT":
            txt = ("Seç / duraklat  |  Blender normal çalışır (seçim, G/R/S, edit mod)  |  "
                   "Kısıt simgesine sağ tık: dondur / sil  |  Q: son çizim aracına dön"
                   "  |  Esc: çizimi kapat")
            if self.msg:
                txt = f"{self.msg}   —   {txt}"
            try:
                context.workspace.status_text_set(txt)
            except Exception:
                pass
            return
        if self.tool.startswith("C_"):
            txt = (f"{self._tool_name()}  |  {self._c_status_text()}  |  Sağ tık: çizime dön  |  "
                   "Simgeye sağ tık: dondur / sil  |  Esc: duraklat")
        else:
            tz = getattr(self, "temp", None)
            if tz is not None:
                plane = f"GEÇİCİ ZEMİN {tz['label']} (G: normale dön, Shift+G: başka zemin)"
            txt = (f"{self._tool_name()} · düzlem: {plane}  |  Tık: nokta  |  Sağ tık/Enter: "
                   "bitir  |  Yaz: ölçü, Tab: sonraki alan  |  W/L/A/E/M/O/R/S/K/P: araç  |  B: kırp  |  Q: önceki "
                   "araç  |  C: kapat  "
                   "|  F: yüzey  |  Ctrl+Z / Ctrl+Shift+Z: taslakta geri al / yinele  |  Shift+Q: düzlem seç  |  G: geçici zemin  |  X/Y/Z: eksen kilidi  |  Shift+X/Y/Z, V: düzlem  |  I: ızgara "
                   f"{'açık' if self.grid_on else 'kapalı'}  |  Shift: 15°  |  Ctrl: yakalama "
                   "yok  |  Esc: duraklat")
        if self.msg:
            txt = f"{self.msg}   —   {txt}"
        try:
            context.workspace.status_text_set(txt)
        except Exception:
            pass

    def _set_tool(self, context, tool):
        if tool == self.tool and tool == "TARC":
            tool = "LINE"
        if tool != self.tool:
            self.prev_tool = self.tool
        self._finalize_stage()
        if tool.startswith("C_") and (self.segs or self.start is not None or self.stage):
            self._commit(context)                 # süren çizgi taslağa; taslak kaydedilmez
        if tool == "SELECT" and self.segs:
            self._commit(context)
        if tool in MODIFY_TOOLS and (self.segs or self.start is not None or self.stage):
            self._commit(context)                 # değiştir araçları taslak üzerinde çalışır
        self._mod_init()
        self.mod, self.off_sel, self.mod_drag = None, None, False
        if tool.startswith("C_") or tool == "SELECT" or tool in MODIFY_TOOLS:
            self.preview = []
            self.cursor = None
            self.info = None
            self.snap_kind = None
        self.tool = tool
        self.c_refs, self.c_hover = [], None
        self.typed, self.field = ["", ""], 0
        msg = ""
        if tool == "SELECT":
            msg = "Duraklatıldı: tıklamalar Blender'a gidiyor · çizmek için pencereden araç seç"
        if tool in XFORM_TOOLS:
            msg = self._xf_begin(context, tool, keep=self.prev_tool in XFORM_TOOLS)
            if not self.sketch:
                msg += " · taslakta çizgi yok (bu araçlar taslakta çalışır)"
        elif tool in MODIFY_TOOLS and tool in MOD_HELP:
            msg = MOD_HELP[tool] if self.sketch else (MOD_HELP[tool] + " · taslakta çizgi yok "
                                                      "(değiştir araçları taslakta çalışır)")
        if tool in PICK_TOOLS:
            msg = PICK_HELP[tool]
        elif tool in CLICK_SHAPES:
            msg = f"{SHAPE_NAMES[tool]}: {STEPS[tool][0]}"
        elif tool == "POINT":
            msg = PICK_HELP["POINT"]
        self._sh_init()
        self.ct_lines, self.pk = [], None
        self.dim_edit = None
        self.fl_sel = None
        self.fillet_eq = None
        self.txt = None
        if tool == "TEXT":
            msg = PICK_HELP["TEXT"]
        if tool not in XFORM_TOOLS:
            self.xf, self.xprev = None, []
            if tool not in MODIFY_TOOLS:
                self.xsel, self.xnodes, self.xpts = set(), set(), set()
        if tool == "TARC" and not self.segs and self.start_tan is None:
            msg = ("Teğet yay: bir çizginin ucundan başlarsan ona teğet devam eder; boşlukta "
                   "başlarsan 3 noktalı yay gibi çizer")
        self._status(context, msg)

    # ------------------------------------------------------------ olaylar

    OVERLAY_REGIONS = {"UI", "TOOLS", "HEADER", "TOOL_HEADER", "ASSET_SHELF",
                       "ASSET_SHELF_HEADER", "NAVIGATION_BAR", "HUD", "FOOTER"}

    MOVE_EVENTS = {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE", "TIMER", "TIMER_REPORT",
                   "TIMERREGION", "NONE", "WINDOW_DEACTIVATE"}

    def _mouse_in_region(self, event):
        r = self.region
        x, y = event.mouse_x - r.x, event.mouse_y - r.y
        inside = 0 <= x < r.width and 0 <= y < r.height
        if inside:
            for o in self.area.regions:
                if o.type in self.OVERLAY_REGIONS and o.width > 1 and o.height > 1:
                    ox, oy = event.mouse_x - o.x, event.mouse_y - o.y
                    if 0 <= ox < o.width and 0 <= oy < o.height:
                        inside = False
                        break
        return inside, x, y

    def _refresh(self, context):
        try:
            self._update(context, *self.mouse)
        except Exception as e:
            print("[Mini CAD] çizim güncellenemedi:", e)
        self._status(context)
        self.area.tag_redraw()

    def _palette_event(self, context, event, mx, my, press):
        """Pencere olaylarını işler; olay pencereye aitse True."""
        pal = self.palette
        if pal.drag is not None:
            if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
                pal.move(mx, my)
                self.area.tag_redraw()
                return True
            if event.type == "LEFTMOUSE" and event.value == "RELEASE":
                pal.release()
                return True
        if not pal.contains(mx, my):
            if pal.hover is not None:
                pal.hover = None
                self.area.tag_redraw()
            return False
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            if pal.move(mx, my):
                self.area.tag_redraw()
            return True
        if event.type == "LEFTMOUSE":
            if not press:
                return True
            h = pal.press(mx, my)
            if h is None:
                return True
            kind, ident = h
            if kind == "close":
                self.stop_request = True
            elif kind == "tool":
                self._set_tool(context, ident)
            elif kind == "cons":
                self._set_tool(context, "C_" + ident)
            elif kind == "sk":
                if ident == "FINISH":
                    self._finish_sketch(context)
                else:
                    self._undo_last(context)
            elif kind == "tgt":
                context.scene.minicad_draw_target = ident
            elif kind == "plane":
                if ident in dm.AXIS_PLANES and self.phase == "PLANE":
                    self._start_offset(context, ident, dm.Plane.axis(ident, (0.0, 0.0, 0.0)))
                else:
                    self._set_plane(ident)
            elif kind == "opt":
                sc = context.scene
                if ident == "auto":
                    sc.minicad_auto_constraints = not sc.minicad_auto_constraints
                elif ident == "show":
                    sc.minicad_show_constraints = not sc.minicad_show_constraints
                elif ident == "snap":
                    self.snap_on = not self.snap_on
                elif ident == "grid":
                    self.grid_on = not self.grid_on
                    sc.minicad_grid_snap = self.grid_on
                elif ident == "look":
                    sc.minicad_look_at = not sc.minicad_look_at
                elif ident == "first":
                    sc.minicad_pick_plane = not sc.minicad_pick_plane
            self._status(context)
            self.area.tag_redraw()
            return True
        return event.type in {"RIGHTMOUSE", "MIDDLEMOUSE"} and False

    def modal(self, context, event):
        # Taslak aşaması için kendi geri al / yinele (Blender'ın geri alması hafızadaki
        # taslağı bilmez). Taslak yoksa Ctrl+Z Blender'a gider.
        if event.type == "Z" and event.value == "PRESS" and event.ctrl and \
                not event.alt and self.sk_drag is None and \
                getattr(self, "phase", "DRAW") == "DRAW" and _STATE["active"] is self:
            self._hist_sync()
            if event.shift and self.redo:
                self._hist_step(context, self.redo, self.hist, "Yinelendi")
                return {"RUNNING_MODAL"}
            if not event.shift and self.hist:
                self._hist_step(context, self.hist, self.redo, "Geri alındı")
                return {"RUNNING_MODAL"}
            if any(st.get("edit_src") for st in self.sketch):
                # taslağa alınmış çizgiler objeden çıktı: Blender'ın geri alması onları
                # objeye geri getirir, Bitir'de çift olurlar
                self._status(context, "Taslakta düzenlenen çizim var: önce Bitir (Ctrl+Enter), "
                                      "sonra geri al")
                return {"RUNNING_MODAL"}
        r = self._modal_inner(context, event)
        if event.type not in self.MOVE_EVENTS and _STATE["active"] is self:
            try:
                self._hist_sync()
            except Exception:
                traceback.print_exc()
        return r

    def _modal_inner(self, context, event):
        if getattr(self, "stop_request", False) or _STATE["active"] is not self:
            self._finish(context)
            return {"CANCELLED"}
        try:
            self.area.regions[0]
        except Exception:
            self._finish(context)
            return {"CANCELLED"}
        inside, mx, my = self._mouse_in_region(event)
        press = event.value == "PRESS"
        self.shift, self.ctrl = event.shift, event.ctrl
        if getattr(self, "jn_drag", None) is not None:      # v0.34.0: kesişim kaydırma
            return self._jn_drag_event(context, event, mx, my, press)
        if self.sk_drag is None and ribbon_state.over_ribbon(event):
            return {"PASS_THROUGH"}          # v0.28.0: fare BlendCAD şeridinde: olay şeridin
        if ribbon_state.is_running():         # v0.30.0: üzerine gelme + sağ tık menüsü
            from . import ribbon_ctx
            r = ribbon_ctx.draw_event(self, context, event, mx, my, inside)
            if r is not None:
                return r

        if getattr(self, "txt", None) is not None and self.phase == "DRAW":
            r = self._txt_event(context, event)             # metin yazılıyor
            if r is not None:
                return r
        if getattr(self, "dim_edit", None) is not None and self.tool.startswith("C_") and \
                event.type not in self.MOVE_EVENTS:
            r = self._c_event(context, event, mx, my, press)     # ölçü değeri yazılıyor
            if r is not None:
                return r
        if event.type == "ESC" and press and self.sk_drag is not None:
            self._drag_cancel()
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and press and self.sk_sel is not None:
            self.sk_sel = None
            self.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and press and self.track is not None:
            self.track = None
            self._status(context, "İz iptal edildi")
            self._refresh(context)
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and press and self.phase == "OFFSET":
            self.phase, self.off = "PLANE", None
            self._status(context)
            self.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and press and self.phase == "PLANE" and \
                getattr(self, "temp_pick", None) is not None:
            self._temp_cancel(context)
            self._refresh(context)
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and press:
            self._finalize_stage()
            if len(self.segs):
                self._commit(context)
            if self.tool != "SELECT" and self.phase != "PLANE":
                self._set_tool(context, "SELECT")   # önce duraklat, ikinci Esc kapatır
                self.area.tag_redraw()
                return {"RUNNING_MODAL"}
            self._finish_sketch(context)          # çıkarken taslak kaybolmasın
            self._finish(context)
            return {"FINISHED"} if self.created else {"CANCELLED"}

        if event.type in MODIFIERS:
            if self.sk_drag is not None:
                if self.sk_drag["moved"]:
                    self._drag_apply(*self.mouse)
                self.area.tag_redraw()
                return {"RUNNING_MODAL"}
            self._refresh(context)
            return {"PASS_THROUGH"}

        if inside and ribbon_state.palette_allowed() and not ribbon_state.is_running() and \
                self._palette_event(context, event, mx, my, press):
            if getattr(self, "stop_request", False):
                self._finish_sketch(context)
                self._finish(context)
                return {"FINISHED"}
            return {"RUNNING_MODAL"}

        if inside and self.phase == "DRAW" and self.sk_drag is None and self.track is None and \
                self.tool not in MODIFY_TOOLS:
            if self._sketch_event(context, event, mx, my, press):
                return {"RUNNING_MODAL"}
        if self.sk_drag is not None:
            return self._drag_event(context, event, mx, my, press)
        if inside and self.phase == "DRAW" and self.track is None and \
                self.tool not in MODIFY_TOOLS and not self.tool.startswith("C_"):
            if self._jn_event(context, event, mx, my, press):      # v0.34.0
                return {"RUNNING_MODAL"}
        if getattr(self, "jn_drag", None) is not None:
            return {"RUNNING_MODAL"}

        if inside and self.phase == "DRAW":
            if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
                if self._glyph_menu_hover(mx, my):
                    self.area.tag_redraw()
            elif event.type == "LEFTMOUSE" and self.gmenu is not None:
                if press:
                    x0, y0, x1, y1 = self.gmenu["box"]
                    if x0 <= mx <= x1 and y0 <= my <= y1:
                        self._glyph_menu_click(context, mx, my)
                    else:
                        self.gmenu = None          # dışarı tık: sadece menüyü kapat
                    self.area.tag_redraw()
                return {"RUNNING_MODAL"}
            elif event.type == "RIGHTMOUSE":
                si_ = self._skc_at(mx, my) if press else None
                if si_ is not None:                  # taslak kısıtı simgesi: sil
                    self._skc_delete(context, si_)
                    return {"RUNNING_MODAL"}
                if press and self._glyph_menu_open(mx, my):
                    self.area.tag_redraw()
                    return {"RUNNING_MODAL"}
                if not press and self.gmenu is not None:
                    return {"RUNNING_MODAL"}

        if self.tool == "SELECT" and self.phase == "DRAW":
            if event.type == "Q" and press and not (event.ctrl or event.alt or event.shift):
                self._set_tool(context, self.prev_tool or "LINE")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type not in self.MOVE_EVENTS:
                self.dirty = True                  # kullanıcı bir şey değiştirmiş olabilir
            return {"PASS_THROUGH"}

        if not inside or event.type in PASS_KEYS:
            if event.type not in self.MOVE_EVENTS:
                self.dirty = True
            return {"PASS_THROUGH"}

        if self.phase == "PLANE":
            return self._modal_plane(context, event, mx, my, press)
        if self.phase == "OFFSET":
            return self._modal_offset(context, event, mx, my, press)
        if self.tool in MODIFY_TOOLS:
            r = self._mod_event(context, event, mx, my, press)
            if r is not None:
                return r
        if self.tool.startswith("C_"):
            r = self._c_event(context, event, mx, my, press)
            if r is not None:
                return r
        if self.track is not None:
            r = self._track_event(context, event, mx, my, press)
            if r is not None:
                return r

        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            try:
                if self.pen is not None:
                    self._pen_drag(mx, my)
                else:
                    self._update(context, mx, my)
            except Exception as e:
                print("[Mini CAD] çizim güncellenemedi:", e)
            self.area.tag_redraw()
            return {"PASS_THROUGH"}

        if event.type == "LEFTMOUSE" and not press:
            if self.pen is not None:
                self._pen_release(context)
                self._refresh(context)
            return {"RUNNING_MODAL"}

        if not press:
            return {"RUNNING_MODAL"} if event.type == "RIGHTMOUSE" else {"PASS_THROUGH"}

        if event.type == "LEFTMOUSE":
            self._update(context, mx, my)
            if self.tool.startswith("C_"):
                self._click_constraint(context)
            elif self.tool == "PEN":
                self.pen = {"co": self.cursor.copy(), "h": None, "id": self.snap_id,
                            "kind": self.snap_kind}
            else:
                self._place(context)
            self._refresh(context)
            return {"RUNNING_MODAL"}

        if event.type in {"RET", "NUMPAD_ENTER"} and event.ctrl:
            self._finish_sketch(context)
            self._refresh(context)
            return {"RUNNING_MODAL"}
        if event.type == "RIGHTMOUSE" or event.type in {"RET", "NUMPAD_ENTER"}:
            if self.tool.startswith("C_"):
                if self.c_refs:
                    self.c_refs = []
                else:
                    self._set_tool(context, "LINE")
            elif event.type != "RIGHTMOUSE" and any(self.typed) and \
                    (self._lock_anchor() is not None or self._coord_on()):
                self._update(context, mx, my)
                self._place(context)              # yazılan değerle noktayı koy
            else:
                self._commit(context)
            self._refresh(context)
            return {"RUNNING_MODAL"}

        if event.type == "DEL" or (event.type == "X" and event.ctrl):
            g = constraints.glyph_at(mx, my)
            if g is not None:
                constraints.remove(bpy.data.objects.get(g[0]), g[1])
                try:
                    bpy.ops.ed.undo_push(message="Mini CAD: Kısıt sil")
                except Exception:
                    pass
                self._status(context, "Kısıt silindi")
                self.area.tag_redraw()
                return {"RUNNING_MODAL"}

        if event.type == "TAB" and event.shift:
            self.coord_mode = not getattr(self, "coord_mode", False)   # hassas giriş
            self.typed, self.field = ["", ""], 0
            self._status(context, "Hassas giriş: ΔX / ΔY (ilk noktada X / Y) · Shift+Tab: uzunluk / "
                                  "açı" if self.coord_mode else "Ölçü girişi: uzunluk / açı · "
                                  "Shift+Tab: X / Y")
            self._refresh(context)
            return {"RUNNING_MODAL"}
        if event.type == "TAB":
            self.field = 1 - self.field
            self._refresh(context)
            return {"RUNNING_MODAL"}

        if event.type == "BACK_SPACE":
            if event.type == "BACK_SPACE" and self.typed[self.field]:
                self.typed[self.field] = self.typed[self.field][:-1]
            elif self.tool.startswith("C_") and self.c_refs:
                self.c_refs.pop()
            else:
                self._undo_last(context)
            self._refresh(context)
            return {"RUNNING_MODAL"}

        ch = event.unicode or ""
        typing = bool(self.typed[self.field])
        if ch and not event.ctrl and (ch in "0123456789.,-+°" or
                                      (typing and (ch.isalpha() or ch in "'\""))):
            if (self._lock_anchor() is not None or (self.track and self.track["pts"]) or
                    self._coord_on()) and not self.tool.startswith("C_"):
                self.typed[self.field] += ch
                self._refresh(context)
            else:
                self._status(context, "Önce ilk noktayı koy, sonra ölçü yaz")
            return {"RUNNING_MODAL"}           # rakamlar Blender'a gitmesin (koleksiyon gizleme)

        if not event.ctrl and not event.alt:
            if event.type == "A":
                self._set_tool(context, "TARC")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type in TOOL_KEYS:
                tool = TOOL_KEYS[event.type]
                cyc = TOOL_CYCLES.get(event.type)
                if cyc and self.tool in cyc:          # tekrar basınca türler arasında geç
                    tool = cyc[(cyc.index(self.tool) + 1) % len(cyc)]
                self._set_tool(context, tool)
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type in {"X", "Y", "Z"} and not event.shift:
                # v0.25.6: Blender gibi eksen kilidi (G → X): dünya ekseni boyunca, tekrar
                # basana kadar; yakalamalar eksene izdüşer, kilidi bozmaz
                ax = {"X": 0, "Y": 1, "Z": 2}[event.type]
                self.axis_lock = None if getattr(self, "axis_lock", None) == ax else ax
                self._status(context, f"Eksen kilidi: {'XYZ'[ax]} (tekrar {event.type}: kapat · "
                                      "Shift+X/Y/Z: düzlem)" if self.axis_lock is not None
                             else "Eksen kilidi kapalı")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type in {"X", "Y", "Z", "V"}:
                mode = {"X": "YZ", "Y": "XZ", "Z": "XY", "V": "VIEW"}[event.type]
                self._set_plane("AUTO" if self.plane_mode == mode else mode)
                # v0.25.10: eksen kilidi açıksa düzlem seçimi etkisiz kalıyordu (eksen kilidi
                # öncelikli) → "Shift+X işe yaramıyor". Düzlem seçmek eksen kilidini kapatır.
                self.axis_lock = None
                self._status(context, f"Düzlem kilidi: {dm.PLANE_LABELS[mode]} — yakalamalar "
                                      f"düzleme izdüşer (tekrar: kapat)"
                             if self.plane_mode == mode else "Düzlem: otomatik")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "T" and not self.tool.startswith("C_") and self.tool != "PEN":
                self.track = {"pts": []}
                self.typed, self.field = ["", ""], 0
                self._status(context, "İz: referans noktaya tıkla, sonra eksen boyunca ilerle "
                                      "(ölçü yazabilirsin) · her tık yeni bacak · Enter / sağ tık:"
                                      " son noktayı kullan · Esc: iptal")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "G" and not self.tool.startswith("C_"):
                # v0.25.6: geçici zemin U → G (sol el ASD bölgesinde; Ground)
                if self.temp is not None and not event.shift:
                    self._temp_end(context)            # asıl düzleme dön
                else:
                    self._temp_begin(context)          # geçici zemin seç (Shift+G: başkası)
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "Q" and event.shift:
                self._set_plane("PICK")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "Q":
                self._set_tool(context, self.prev_tool or "SELECT")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "I":
                self.grid_on = not self.grid_on
                try:
                    context.scene.minicad_grid_snap = self.grid_on
                except Exception:
                    pass
                self._status(context, f"Izgara yakalama {'açık' if self.grid_on else 'kapalı'}")
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "D" and self.tool == "POLYGON":
                self.poly_inner = not self.poly_inner     # iç / dış teğet çokgen
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "D":
                self.carc_flip = not self.carc_flip
                self._refresh(context)
                return {"RUNNING_MODAL"}
            if event.type == "C":
                self._close(context)
                self._refresh(context)
                return {"RUNNING_MODAL"}
        if event.type == "F" and not event.alt:
            self._surface(context, new_body=event.ctrl)
            self._refresh(context)
            return {"RUNNING_MODAL"}

        if event.type not in self.MOVE_EVENTS:
            self.dirty = True
        return {"PASS_THROUGH"}


def edit_target(context, name=""):
    """Düzenlenecek çizim: verilen ad, Outliner seçimi ya da aktif obje (eğri olmalı)."""
    if name:
        ob = bpy.data.objects.get(name)
        return ob if ob is not None and ob.type == "CURVE" else None
    act = getattr(context, "active_object", None)
    ids = [i for i in (getattr(context, "selected_ids", None) or ())   # Outliner seçimi
           if getattr(i, "type", None) == "CURVE" and hasattr(i, "matrix_world")]
    if ids:
        return act if act in ids else ids[0]
    if act is not None and act.type == "CURVE":
        return act
    sel = [o for o in (getattr(context, "selected_objects", None) or ()) if o.type == "CURVE"]
    return sel[0] if sel else None


def _view3d(context):
    """Çizim aracının açılacağı 3D görünüm: (pencere, alan, bölge) ya da None."""
    win = getattr(context, "window", None)
    area = getattr(context, "area", None)
    if area is not None and area.type == "VIEW_3D" and win is not None:
        cands = [(win, area)]
    else:
        cands = []
        for w in getattr(context.window_manager, "windows", ()):
            for a in w.screen.areas:
                if a.type == "VIEW_3D":
                    cands.append((w, a))
        cands.sort(key=lambda wa: (wa[0] is not win, -wa[1].width * wa[1].height))
    for w, a in cands:
        r = next((r for r in a.regions if r.type == "WINDOW"), None)
        if r is not None:
            return w, a, r
    return None


class MINICAD_OT_edit_sketch(bpy.types.Operator):
    """Inventor "Edit Sketch": kaydedilmiş (Bitir'lenmiş) çizimi yeniden taslağa alır."""
    bl_idname = "minicad.edit_sketch"
    bl_label = "Çizimi Düzenle"
    bl_description = ("Seçili çizimi (eğri objesi) yeniden taslağa alır: bütün çizim, değiştir "
                      "ve kısıt araçlarıyla düzenlenir, Bitir (Ctrl+Enter) ile aynı objeye aynı "
                      "spline sırasıyla geri yazılır. Ona bağlı yüzey ve kısıtlar korunur "
                      "(Inventor 'Edit Sketch')")
    bl_options = {"REGISTER"}

    name: bpy.props.StringProperty(name="Çizim", default="", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        try:
            return edit_target(context) is not None
        except Exception:
            return False

    def execute(self, context):
        name = getattr(self, "name", "") or ""
        ob = edit_target(context, name if isinstance(name, str) else "")
        if ob is None:
            self.report({"WARNING"}, "Düzenlenecek çizim (eğri objesi) seçili değil")
            return {"CANCELLED"}
        if getattr(ob, "mode", "OBJECT") != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass
        # Taslağa alınmadan önceki hâl geri alma adımı olsun: Bitir'den sonra Ctrl+Z buraya döner
        try:
            bpy.ops.ed.undo_push(message="Mini CAD: Çizimi Düzenle")
        except Exception:
            pass
        op = _STATE["active"]
        if op is not None:                       # çizim aracı açık: taslağa eklenir
            if op.sketch and any(st.get("edit_src", {}).get("obj") == ob.name
                                 for st in op.sketch):
                self.report({"INFO"}, f"'{ob.name}' zaten taslakta düzenleniyor")
                return {"CANCELLED"}
            n = op._edit_load_all(context, ob.name)
            op._refresh(context)
            return {"FINISHED"} if n else {"CANCELLED"}
        v = _view3d(context)
        if v is None:
            self.report({"ERROR"}, "Çizim için 3D görünüm bulunamadı")
            return {"CANCELLED"}
        w, a, r = v
        try:
            with context.temp_override(window=w, area=a, region=r):
                bpy.ops.minicad.draw("INVOKE_DEFAULT", edit_curve=ob.name)
        except Exception as e:
            self.report({"ERROR"}, f"Çizim açılamadı: {e}")
            return {"CANCELLED"}
        return {"FINISHED"}


def _menu_edit_sketch(self, context):
    try:
        if edit_target(context) is None:
            return
    except Exception:
        return
    self.layout.separator()
    self.layout.operator("minicad.edit_sketch", text="BlendCAD: Çizimi Düzenle",
                         icon="CURVE_BEZCURVE")


_MENUS = ("OUTLINER_MT_object", "VIEW3D_MT_object_context_menu")

classes = (MINICAD_OT_draw, MINICAD_OT_edit_sketch)


@bpy.app.handlers.persistent
def _on_load_pre(_dummy):
    cleanup_all(save=False)                    # eski sahne gidiyor: yazılacak yer yok


@bpy.app.handlers.persistent
def _on_save_pre(_dummy):
    """Dosya kaydedilirken taslağa alınmış (Çizimi Düzenle) çizgiler objede yok: kaydetmeden
    önce Bitir'lenir, yoksa dosyada çizim eksik kalırdı. Araç açık kalır."""
    op = _STATE["active"]
    if op is None or getattr(op, "stop_request", False):
        return
    if not any(st.get("edit_src") for st in (getattr(op, "sketch", None) or ())):
        return
    save_sketch(op)
    try:
        op._status(bpy.context, "Kaydetmeden önce düzenlenen çizim Bitir'lendi")
    except Exception:
        pass


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.minicad_grid_snap = bpy.props.BoolProperty(
        name="Izgara Yakalama", description="Çizerken ızgaraya hafif yakalama (I)", default=True)
    bpy.types.Scene.minicad_draw_target = bpy.props.EnumProperty(
        name="Çizim Hedefi", description="Bitir'e basınca taslak nereye kaydedilsin",
        items=[("ACTIVE", "Mevcut eğri", "Aktif / son kullanılan eğri objesine yeni spline "
                "olarak eklenir"),
               ("NEW", "Yeni eğri", "Her Bitir'de yeni bir eğri objesi oluşturulur")],
        default="ACTIVE")
    bpy.types.Scene.minicad_grid_alpha = bpy.props.FloatProperty(
        name="Izgara Görünürlüğü", description="Çizerken imleç çevresindeki ızgara çizgilerinin "
        "belirginliği (0 = gizli; yakalama yine çalışır)", default=0.22, min=0.0, max=1.0,
        subtype="FACTOR")
    bpy.types.Scene.minicad_grid_fade = bpy.props.FloatProperty(
        name="Izgara Yumuşaklığı", description="Izgaranın kenara doğru silikleşmesi (spot ışığı "
        "gibi): 0 = keskin kenarlı daire, 1 = merkezden başlayan yumuşak geçiş",
        default=0.7, min=0.0, max=1.0, subtype="FACTOR")
    bpy.types.Scene.minicad_grid_size = bpy.props.FloatProperty(
        name="Izgara Yarıçapı", description="İmleç çevresindeki ızgara alanının yarıçapı "
        "(ızgara aralığı cinsinden)", default=6.0, min=2.0, max=30.0)
    bpy.types.Scene.minicad_look_at = bpy.props.BoolProperty(
        name="Düzleme Bak", description="Çizim düzlemi seçilince görünümü düzleme çevir",
        default=True)
    bpy.types.Scene.minicad_pick_plane = bpy.props.BoolProperty(
        name="Önce Düzlem Seç", description="Çizim açılınca önce çizim düzlemini seçtir "
        "(Inventor gibi). v0.30.0: varsayılan kapalı — araçlar otomatik düzlemle açılır, "
        "düzlemi Eskiz başlat ya da Shift+Q seçtirir", default=False)
    bpy.app.handlers.load_pre.append(_on_load_pre)
    if hasattr(bpy.app.handlers, "save_pre"):
        bpy.app.handlers.save_pre.append(_on_save_pre)
    for m in _MENUS:
        mt = getattr(bpy.types, m, None)
        if mt is not None and hasattr(mt, "append"):
            mt.append(_menu_edit_sketch)


def unregister():
    cleanup_all()
    for m in _MENUS:
        mt = getattr(bpy.types, m, None)
        if mt is not None and hasattr(mt, "remove"):
            try:
                mt.remove(_menu_edit_sketch)
            except Exception:
                pass
    if _on_load_pre in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(_on_load_pre)
    sv = getattr(bpy.app.handlers, "save_pre", None)
    if sv is not None and _on_save_pre in sv:
        sv.remove(_on_save_pre)
    for name in ("minicad_grid_snap", "minicad_grid_alpha", "minicad_grid_fade",
                 "minicad_grid_size", "minicad_draw_target",
                 "minicad_look_at",
                 "minicad_pick_plane"):
        try:
            delattr(bpy.types.Scene, name)
        except Exception:
            pass
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
