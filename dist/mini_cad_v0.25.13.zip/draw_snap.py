"""Yakalama ve çıkarım: nokta yakalama, sezgisel kılavuzlar (FORGE snap_math), teğet
uzantılar, yay devamı, eksen kilitleri, önizleme ve T ile iz (başlangıç noktası tayini).

MINICAD_OT_draw (draw.py) bu mixin'den miras alır; metotlar self üzerinden birbirini çağırır.
"""
import bpy
import math
import numpy as np
from mathutils import Vector

from . import constraints
from . import core
from . import drawmath as dm
from . import surfmath as sfm
from .draw_common import (
    ATTACH_KINDS, CLICK_SHAPES, COL_GUIDE, COL_SNAP, FIELDS, GRID_PX, GUIDE_PX, MODIFY_TOOLS, PRIORITY, REF_PX,
    SHAPE_TOOLS,
    _Refs,
    _axis_col, _dashed, _marker, _project, _seg_px_dist, _text, parse_angle, parse_length,
)


PLANE_LOCK_MODES = {"XY", "XZ", "YZ", "VIEW"}   # açıkça seçilen düzlem: yakalama izdüşer


def _line_off(q, o, d):
    """q'nun (o, d) doğrusuna dik uzaklık vektörü (d birim)."""
    w = np.asarray(q, dtype=np.float64) - o
    return w - d * float(w @ d)


class SnapMixin:
    """Yakalama ve çıkarım: nokta yakalama, sezgisel kılavuzlar (FORGE snap_math), teğet
    uzantılar, yay devamı, eksen kilitleri, önizleme ve T ile iz (başlangıç noktası tayini)."""

    def _anchor(self):
        if self.segs:
            return self.segs[-1]["p"][3]
        return self.start

    # ------------------------------------------------------------ yay ölçü girişi (v0.25.3)

    def _arc_phase(self):
        """Yay araçlarının adımı: ARC3_END (bitiş noktası), ARC3_BULGE (eğrilik), CARC_CENTER,
        CARC_END, TAN (teğet yay) ya da None."""
        t = self.tool
        if t == "TARC" and self._prev_tangent() is not None:
            return "TAN"
        if t in ("ARC3", "TARC"):
            return "ARC3_BULGE" if self.stage else "ARC3_END"
        if t == "CARC":
            if self._anchor() is None:           # önce merkez, sonra başlangıç
                return "CARC_START" if self.stage else None
            return "CARC_END" if self.stage else "CARC_CENTER"   # zincirden: merkez, bitiş
        return None

    ARC_FIELDS = {"ARC3_END": ("Uzunluk", "Açı"), "ARC3_BULGE": ("Yarıçap", "Yay açısı"),
                  "CARC_CENTER": ("Yarıçap", "Açı"), "CARC_START": ("Yarıçap", "Açı"),
                  "CARC_END": ("Yay açısı", None),
                  "TAN": ("Yarıçap", "Yay açısı")}

    def _fields(self):
        """Etkin aracın (ve adımının) ölçü alanları."""
        ph = self._arc_phase()
        if ph is not None:
            return self.ARC_FIELDS[ph]
        return FIELDS.get(self.tool, ("Uzunluk", "Açı"))

    def _point_lock_fields(self):
        """Noktayı (uzunluk / açıyla) kilitleyen alanlar; yayın kendi ölçüleri değil."""
        if self._arc_phase() in ("ARC3_BULGE", "CARC_END", "TAN"):
            return (None, None)
        return self._fields()

    def _arc_typed(self, plane):
        """Yazılan yarıçap / yay açısıyla yayı kur (imleç yalnızca yönü / yanı seçer)."""
        ph = self._arc_phase()
        if ph not in ("ARC3_BULGE", "CARC_END", "TAN") or not any(self.typed):
            return
        anchor = self._anchor()
        cur = self.cursor
        n = plane.n
        f0, _f1 = self.ARC_FIELDS[ph]
        R = parse_length(self.typed[0]) if f0 == "Yarıçap" and self.typed[0] else None
        th_txt = self.typed[0] if f0 == "Yay açısı" else self.typed[1]
        th = parse_angle(th_txt) if th_txt else None
        if R is not None and R <= 1e-12:
            R = None
        if th is not None:
            th = math.radians(th % 360.0) if abs(th) % 360.0 > 1e-9 else None
        if R is None and th is None:
            return
        if ph == "ARC3_BULGE":
            A, E = anchor, self.stage[0]
            c = E - A
            L = float(np.linalg.norm(c))
            perp = dm.unit(np.cross(n, c))
            if L < 1e-12 or perp is None:
                return
            M0 = 0.5 * (A + E)
            side = 1.0 if float(np.dot(cur - M0, perp)) >= 0 else -1.0
            if R is not None:
                R = max(R, 0.5 * L)
                th = 2.0 * math.asin(min(1.0, L / (2.0 * R)))
            else:
                R = L / (2.0 * math.sin(th / 2.0))
            h = R * (1.0 - math.cos(th / 2.0))
            arc = dm.arc_3pt(A, M0 + side * perp * h, E)
        elif ph == "CARC_END":
            C, A = self.stage[0], anchor
            v = A - C
            v = v - np.dot(v, n) * n
            R0 = float(np.linalg.norm(v))
            if th is None or R0 < 1e-12:
                return
            e1 = v / R0
            e2 = np.cross(n, e1)
            d = 1.0
            if self.arc_info is not None and self.preview:     # yön: imlecin önizlemesi
                q = self.preview[0]["p"][1] - A
                d = 1.0 if float(np.dot(q, e2)) >= 0 else -1.0
            segs = dm._arc_from_basis(C, R0, e1, d * e2, th, A, None)
            arc = {"segs": segs, "radius": R0, "angle": th, "center": C}
        else:                                                   # TAN
            t0 = dm.unit(self._prev_tangent() - np.dot(self._prev_tangent(), n) * n)
            side_v = dm.unit(np.cross(n, t0)) if t0 is not None else None
            if side_v is None:
                return
            if float(np.dot(cur - anchor, side_v)) < 0:
                side_v = -side_v
            if R is None:
                R = (self.arc_info or {}).get("radius")
                if not R:
                    return
            ctr = anchor + side_v * R
            if th is None:
                w = cur - ctr
                th = math.atan2(float(np.dot(w, t0)), float(np.dot(w, -side_v))) % (2 * math.pi)
                if th < 1e-6:
                    return
            segs = dm._arc_from_basis(ctr, R, -side_v, t0, th, anchor, None)
            arc = {"segs": segs, "radius": R, "angle": th, "center": ctr,
                   "end_tangent": -math.sin(th) * (-side_v) + math.cos(th) * t0}
            if not self.segs:
                for sg in segs:
                    sg["tan_start"] = True
        if arc is not None:
            self.preview, self.arc_info = arc["segs"], arc

    def _prev_tangent(self):
        if self.segs:
            return dm.end_tangent(self.segs[-1])
        return self.start_tan[0] if self.start_tan is not None else None

    def _end_tangent_of(self, pid):
        """Var olan bir çizginin ucundan dışarı doğru teğet (uç değilse None).
        (yön, (obje adı, spline, uca bağlı segment))"""
        ob = bpy.data.objects.get(pid[0])
        if ob is None or ob.type != "CURVE":
            return None
        try:
            sp = ob.data.splines[pid[1]]
        except Exception:
            return None
        if sp.use_cyclic_u:
            return None
        mw = ob.matrix_world
        k = pid[2]
        if sp.type == "BEZIER":
            bps = sp.bezier_points
            n = len(bps)
            if k == 0 and n > 1:
                t = np.array(mw @ bps[0].co) - np.array(mw @ bps[0].handle_right)
                if np.linalg.norm(t) < 1e-12:
                    t = np.array(mw @ bps[0].co) - np.array(mw @ bps[1].co)
                seg = 0
            elif k == n - 1 and n > 1:
                t = np.array(mw @ bps[k].co) - np.array(mw @ bps[k].handle_left)
                if np.linalg.norm(t) < 1e-12:
                    t = np.array(mw @ bps[k].co) - np.array(mw @ bps[k - 1].co)
                seg = k - 1
            else:
                return None
        else:
            pts = sp.points
            n = len(pts)
            if k == 0 and n > 1:
                t, seg = np.array(mw @ pts[0].co.xyz) - np.array(mw @ pts[1].co.xyz), 0
            elif k == n - 1 and n > 1:
                t, seg = np.array(mw @ pts[k].co.xyz) - np.array(mw @ pts[k - 1].co.xyz), k - 1
            else:
                return None
        t = dm.unit(t)
        return None if t is None else (t, (pid[0], pid[1], seg))

    def _temp_tangent(self, st):
        """Geçici zeminde başlangıç teğetini zemine izdüşürür; kısıt kaynağı olmaz."""
        tp = self._temp_plane()
        if st is None or tp is None or self.snap_src is None:
            return st
        t = np.asarray(st[0]) - tp.n * float(np.dot(st[0], tp.n))
        t = dm.unit(t)
        return None if t is None or float(np.linalg.norm(t)) < 1e-6 else (t, ("@proj", 0, 0, 0))

    def _sketch_end_tangent(self, p):
        """Taslaktaki açık bir çizginin ucundan dışarı doğru teğet (p o uçtaysa; en son
        çizilen öncelikli). (yön, ("@sketch", çizgi, uca bağlı segment, uç: 0 / 3))"""
        if p is None:
            return None
        p = np.asarray(p, dtype=np.float64)
        tol = 1e-7 * (1.0 + float(np.abs(p).max()))
        for k in range(len(self.sketch) - 1, -1, -1):
            st = self.sketch[k]
            segs = st["segs"]
            if st["cyclic"] or not segs:
                continue
            for j, end in ((len(segs) - 1, 3), (0, 0)):
                sg = segs[j]
                if float(np.linalg.norm(np.asarray(sg["p"][end]) - p)) > tol:
                    continue
                t = dm.end_tangent(sg) if end == 3 else dm.start_tangent(sg)
                if t is None:
                    continue
                return (t if end == 3 else -t), ("@sketch", k, j, end)
        return None

    def _lock_anchor(self):
        """Yazılan değerlerin ve kılavuzların ölçüldüğü nokta."""
        if self.tool in CLICK_SHAPES and self.stage:
            return self.stage[-1]
        if self.tool in SHAPE_TOOLS and self.stage:
            return self.stage[0]
        if self.tool in ("CV", "FIT") and self.stage:
            return self.stage[-1]
        if self.tool == "CARC" and self.stage and self._anchor() is None:
            return self.stage[0]                 # merkezli yay: başlangıç merkeze göre (v0.25.3)
        return self._anchor()

    def _point_snap(self, mx, my, ro, rd):
        M = np.array(self.rv3d.perspective_matrix, dtype=np.float64)
        m = np.array([mx, my])
        refs = self.refs
        extra = self._extra_pts()
        anchor = self._lock_anchor()
        P = refs.P
        kinds = list(refs.kinds)
        ids = list(refs.ids)
        if extra:
            P = np.vstack([P] + [np.asarray(p).reshape(1, 3) for p, _ in extra])
            kinds += [k for _, k in extra]
            ids += [None] * len(extra)
        if len(P):
            px, ok, z = _project(P, M, self.region)
            d = np.linalg.norm(px - m, axis=1)
            d = np.where(ok, d, np.inf)
            idx = np.where(d <= self.radius)[0]
            if anchor is not None:            # kendi çapasına yapışmasın
                idx = [i for i in idx if np.linalg.norm(P[i] - anchor) > 1e-9]
            if len(idx):
                best = min(idx, key=lambda i: (PRIORITY[kinds[i]], d[i], z[i]))
                return P[best], kinds[best], ids[best]
        if refs.chords:
            A = np.array([c[0] for c in refs.chords])
            B = np.array([c[1] for c in refs.chords])
            pa, oka, _ = _project(A, M, self.region)
            pb, okb, _ = _project(B, M, self.region)
            dd, _ = _seg_px_dist(pa, pb, m)
            dd = np.where(oka & okb, dd, np.inf)
            near = [int(i) for i in np.argsort(dd)[:16] if dd[i] <= self.radius]
            best = None
            for ii in range(len(near)):
                for jj in range(ii + 1, len(near)):
                    a, b = refs.chords[near[ii]]
                    c, e = refs.chords[near[jj]]
                    tol = 1e-4 * min(np.linalg.norm(b - a), np.linalg.norm(e - c)) + 1e-9
                    q = dm.segment_intersection(a, b, c, e, tol)
                    if q is None:
                        continue
                    qp = self._px(q)
                    if qp is None:
                        continue
                    dq = math.hypot(qp[0] - mx, qp[1] - my)
                    if dq <= self.radius and (best is None or dq < best[0]):
                        best = (dq, q)
            if best is not None:
                return best[1], "Kesişim", None
        if len(refs.A):
            pa, oka, za = _project(refs.A, M, self.region)
            pb, okb, zb = _project(refs.B, M, self.region)
            dd, t = _seg_px_dist(pa, pb, m)
            dd = np.where(oka & okb, dd, np.inf)
            dmin = dd.min()
            if np.isfinite(dmin) and dmin <= self.radius * 0.8:
                near = np.where(dd <= dmin + 2.0)[0]
                z = za + (zb - za) * t
                k = int(near[np.argmin(z[near])])
                q = dm.closest_on_segment_to_ray(refs.A[k], refs.B[k], ro, rd)
                g = self._ref_geo(k)
                if g is not None and g[0] == "bez":
                    # v0.25.12: çoklu çizgi kirişi değil, gerçek eğrinin üstü (Bitir'de eğriye
                    # nokta eklenip bağlanabilsin)
                    q = sfm.bez(g[1], sfm.bez_ray_closest(g[1], ro, rd))
                return q, "Yakın", None
        return None

    def _ref_geo(self, k):
        """refs.A / B satırının ait olduğu eğrinin tam geometrisi: ("bez", (4,3)) | ("poly", ..)"""
        refs = self.refs
        own = getattr(refs, "own", None)
        geo = getattr(refs, "geo", None)
        if own is None or geo is None or not (0 <= k < len(own)):
            return None
        j = int(own[k])
        return geo[j] if 0 <= j < len(geo) else None

    def _lock_curve_hit(self, mx, my, lock, radius=None):
        """v0.25.12: kilitli koordinatta eğri yakalaması. lock = ("plane", o, n) | ("line", o,
        d). İmlece yakın eğrilerin kilitle (düzlem / eksen doğrusu) kesiştiği noktalardan
        ekranda imlece en yakını: (nokta, piksel uzaklığı) | None. Nokta hem eğrinin hem
        kilidin üstündedir: kilit bozulmaz, nokta eğriye bağlanabilir."""
        refs = self.refs
        geo = getattr(refs, "geo", None)
        if not geo or not len(refs.A):
            return None
        lim = (radius if radius is not None else self.radius) * 1.25
        M = np.array(self.rv3d.perspective_matrix, dtype=np.float64)
        m = np.array([mx, my])
        pa, oka, _ = _project(refs.A, M, self.region)
        pb, okb, _ = _project(refs.B, M, self.region)
        dd, _t = _seg_px_dist(pa, pb, m)
        dd = np.where(oka & okb, dd, np.inf)
        rows = np.where(dd <= lim * 2.0)[0]
        owners = sorted({int(refs.own[k]) for k in rows})
        kind, o, v = lock
        o = np.asarray(o, dtype=np.float64)
        v = np.asarray(v, dtype=np.float64)
        best = None
        for j in owners:
            gk, G = geo[j]
            scale = 1.0 + float(np.abs(G).max()) + float(np.abs(o).max())
            if gk == "bez":
                if kind == "plane":
                    qs = [sfm.bez(G, t) for t in sfm.bez_plane_hits(G, o, v)]
                else:
                    qs = [sfm.bez(G, t) for t in sfm.bez_line_hits(G, o, v, 1e-6 * scale)]
            else:
                qs = sfm.poly_plane_hits(G, o, v) if kind == "plane" else \
                    sfm.poly_line_hits(G, o, v, 1e-6 * scale)
            for q in qs:
                qp = self._px(q)
                if qp is None:
                    continue
                dq = math.hypot(qp[0] - mx, qp[1] - my)
                if dq <= lim and (best is None or dq < best[1]):
                    best = (np.asarray(q, dtype=np.float64), dq)
        return best

    def _inference_refs(self, plane, mx, my):
        M = np.array(self.rv3d.perspective_matrix, dtype=np.float64)
        m = np.array([mx, my])
        refs = self.refs
        lim = REF_PX * self.ui_scale
        ref_pts = []
        pts = [refs.P[i] for i, k in enumerate(refs.kinds) if k in ("Uç", "Merkez", "Orta")]
        pts += [p for p, _ in self._extra_pts()]
        if pts:
            P = np.array(pts)
            px, ok, _ = _project(P, M, self.region)
            d = np.where(ok, np.linalg.norm(px - m, axis=1), np.inf)
            for i in np.argsort(d)[:30]:
                if d[i] > lim:
                    break
                u, v = plane.uv(P[i])
                ref_pts.append((u, v, int(i)))
        chords = [(a, b, cid) for (a, b), cid in zip(refs.chords, refs.chord_ids)]
        chords += [(s["p"][0], s["p"][3], ("chain", j)) for j, s in enumerate(self.segs)
                   if s["kind"] == "line"]
        self._cur_chords = []
        ref_dirs, ref_segs = [], []
        if chords:
            A = np.array([c[0] for c in chords])
            B = np.array([c[1] for c in chords])
            pa, oka, _ = _project(A, M, self.region)
            pb, okb, _ = _project(B, M, self.region)
            dd, _ = _seg_px_dist(pa, pb, m)
            dd = np.where(oka & okb, dd, np.inf)
            for i in np.argsort(dd)[:12]:
                if dd[i] > lim * 0.8:
                    break
                a, b, cid = chords[int(i)]
                dvec = dm.unit(b - a)
                if dvec is None or abs(float(np.dot(dvec, plane.n))) > 0.02:
                    continue                    # düzlemde değil
                j = len(self._cur_chords)
                self._cur_chords.append((a, b, cid))
                ua, va = plane.uv(a)
                ub, vb = plane.uv(b)
                ref_dirs.append((ub - ua, vb - va, j))
                ref_segs.append(((ua, va), (ub, vb), j))
        # eğri / yay uçlarından teğet doğrultusunda uzantılar
        rays = list(refs.rays)
        for s in self.segs:
            if s["kind"] != "line":
                t1 = dm.unit(s["p"][3] - s["p"][2])
                if t1 is not None:
                    rays.append((s["p"][3], t1))
        if rays:
            E = np.array([r[0] for r in rays])
            pe, oke, _ = _project(E, M, self.region)
            de = np.where(oke, np.linalg.norm(pe - m, axis=1), np.inf)
            for i in np.argsort(de)[:16]:
                if de[i] > lim * 1.5:
                    break
                e, t = rays[int(i)]
                if abs(float(np.dot(t, plane.n))) > 0.02:
                    continue
                ue, ve = plane.uv(e)
                ut = (float(np.dot(t, plane.u)), float(np.dot(t, plane.v)))
                k = 1e-3 * (1.0 + abs(ue) + abs(ve))
                ref_segs.append(((ue - ut[0] * k, ve - ut[1] * k), (ue, ve), "ray"))
        return ref_pts, ref_dirs, ref_segs

    def _refs_sync(self, context):
        """Taslak / kaydedilmiş eğriler değiştiyse yakalama ve sınır referanslarını yeniler."""
        if self.dirty:
            try:
                self.refs = _Refs(context, self.sketch, getattr(self, "sk_points", None) or ())
            except Exception:
                pass
            self.dirty = False

    def _update(self, context, mx, my):
        self.mouse = (mx, my)
        self._refs_sync(context)
        if self.phase == "PLANE":
            self._hover_plane(context, mx, my)
            self.plane_snap = None                 # yön seçerken de noktalara yapışır
            if not self.ctrl and self.snap_on and getattr(self, "temp_pick", None) is not None:
                ro, rd = self._ray(mx, my)
                sn = self._point_snap(mx, my, ro, rd)
                if sn is not None and sn[1] != "Yakın":
                    self.plane_snap = (np.asarray(sn[0], dtype=np.float64), sn[1])
            self.cursor = None
            self.preview = []
            return
        if self.tool == "SELECT":
            self.cursor, self.preview, self.info, self.snap_kind = None, [], None, None
            return
        if self.tool in MODIFY_TOOLS:
            self._mod_update(context, mx, my)
            return
        if self.track is not None:
            self._track_update(context, mx, my)
            return
        if self.tool.startswith("C_"):
            self.c_hover = self._c_pick(mx, my)
            return
        ro, rd = self._ray(mx, my)
        anchor = self._lock_anchor()
        no_snap = self.ctrl or not self.snap_on
        snap = None if no_snap else self._point_snap(mx, my, ro, rd)
        f0, f1 = self._point_lock_fields()
        v0 = (parse_length(self.typed[0]) if f0 else None) if anchor is not None else None
        v1 = None
        if anchor is not None and f1:
            v1 = parse_length(self.typed[1]) if self.tool == "RECT" else parse_angle(self.typed[1])
        if self._coord_on():                 # hassas giriş: ΔX / ΔY (ilk noktada X / Y)
            v0 = self._signed_len(self.typed[0]) if self.typed[0] else None
            v1 = self._signed_len(self.typed[1]) if self.typed[1] else None
        locked = v0 is not None or v1 is not None

        # Çalışma düzlemi
        plane = self._cur_plane()
        had_plane = plane is not None
        if plane is None:
            if snap is not None:
                plane = self._make_plane(self.plane_mode, snap[0])
            else:
                face_n, origin = None, np.array(context.scene.cursor.location)
                if self.plane_mode == "AUTO":
                    try:
                        hit, loc, nor, _i, obj, _m = context.scene.ray_cast(
                            context.evaluated_depsgraph_get(), Vector(tuple(ro)),
                            Vector(tuple(rd)))
                        if hit and obj is not None and obj.type == "MESH" and \
                                obj.display_type in ("SOLID", "TEXTURED"):
                            face_n, origin = np.array(nor), np.array(loc)
                    except Exception:
                        pass
                plane = self._make_plane(self.plane_mode, origin, face_n)
            self.tmp_plane = plane
        elif anchor is not None and abs(plane.dist(anchor)) > 1e-9:
            plane = plane.moved(anchor)

        self.info = None
        self.snap_kind = self.snap_id = None
        self.snap_attach = None
        lock_hit = None
        if had_plane and not no_snap and not locked and \
                self.plane_mode in PLANE_LOCK_MODES | {"LOCK"} and \
                self.tool not in SHAPE_TOOLS and getattr(self, "axis_lock", None) is None:
            # v0.25.12: düzlem kilidinde eğrinin düzlemi kestiği nokta öncelikli (kilit hiç
            # bozulmaz; düzlem dışındaki yakalamalar izdüşer). Düzlemdeki uç / orta / merkez
            # yakalamaları yine önce gelir.
            snap_on_plane = snap is not None and PRIORITY.get(snap[1], 3) <= 1 and \
                abs(float(plane.dist(np.asarray(snap[0], dtype=np.float64)))) <= \
                1e-9 * (1.0 + float(np.abs(snap[0]).max()))
            if not snap_on_plane:
                lock_hit = self._lock_curve_hit(mx, my, ("plane", plane.o, plane.n))
        if lock_hit is not None:
            p = lock_hit[0]
            self.snap_kind = "Eğri"
            self.info = {"kind": f"{dm.PLANE_LABELS.get(plane.name, plane.name)} ∩ eğri",
                         "plane": plane}
        elif snap is not None and not locked:
            p = np.asarray(snap[0], dtype=np.float64)
            self.snap_kind, self.snap_id = snap[1], snap[2]
            if had_plane and self.plane_mode in PLANE_LOCK_MODES and \
                    abs(float(plane.dist(p))) > 1e-9:
                # v0.25.10: açıkça seçilmiş düzlemde (Shift+X/Y/Z, V) düzlem dışındaki noktaya
                # yapışınca çizim düzlemden çıkıyordu. Nokta düzleme izdüşer (eksen kilidindeki
                # gibi "hiza"); kilit bozulmaz.
                p = p - plane.n * plane.dist(p)
                self.snap_kind = self.snap_id = None
                self.info = {"kind": f"{dm.PLANE_LABELS.get(plane.name, plane.name)} · "
                                     f"{snap[1]} hizası", "plane": plane}
        else:
            p = self._plane_hit(plane, ro, rd) if self.plane_mode in dm.AXIS_PLANES \
                else plane.ray_hit(ro, rd)
            if p is None:
                p = self.cursor if self.cursor is not None else plane.o
            if not no_snap and not locked:
                tol = GUIDE_PX * self.ui_scale * self._px_size(p)
                ref_pts, ref_dirs, ref_segs = self._inference_refs(plane, mx, my)
                a_uv = plane.uv(anchor) if anchor is not None else None
                pt = self._prev_tangent() if self.tool not in SHAPE_TOOLS else None
                prev = None
                if pt is not None:
                    prev = (float(np.dot(pt, plane.u)), float(np.dot(pt, plane.v)))
                q, info = dm.refine(a_uv, plane.uv(p), ref_dirs, ref_pts, ref_segs, tol,
                                    shift=self.shift, prev_dir=prev)
                if info is None or info.get("kind") == "Hiza":
                    p2 = self._arc_continue(plane, plane.xyz(q) if info else p, tol,
                                            info.get("guides") if info else None)
                    if p2 is not None:
                        p = p2
                        kind = "Yay uzantısı" + (" + Hiza" if info else "")
                        info = dict(info or {}, kind=kind)
                        q = plane.uv(p)
                if info is not None:
                    p = plane.xyz(q) + plane.n * plane.dist(p)
                    info["plane"] = plane
                    self.info = info
                if self.grid_on:
                    p2, g = self._grid_snap(plane, p, self.info)
                    if g:
                        p = p2
                        if self.info is None:
                            self.info = {"kind": "Izgara", "plane": plane}
                        else:
                            self.info["kind"] += " + Izgara"
            if locked:
                p = self._apply_locks(plane, anchor, p, v0, v1)
        ax_i = getattr(self, "axis_lock", None)
        if ax_i is not None and anchor is not None and self.tool not in SHAPE_TOOLS and \
                self.tool not in CLICK_SHAPES:
            p = self._axis_point(anchor, ax_i, ro, rd, snap, no_snap)
            self.cursor = np.asarray(p, dtype=np.float64)      # eksen kilidi zemine izdüşmez
            self._set_attach()
            self._make_preview(plane)
            return
        self.cursor = self._on_temp(np.asarray(p, dtype=np.float64))
        self._set_attach()
        self._make_preview(plane)

    def _set_attach(self):
        """Nokta bir eğrinin üstüne yapıştıysa (Yakın / kilitli kesişim) hatırlanır: tıklanınca
        Bitir'de o eğriye nokta eklenip çizgiye bağlanır (v0.25.12)."""
        self.snap_attach = None
        if self.cursor is not None and self.snap_kind in ATTACH_KINDS and \
                self.tool not in SHAPE_TOOLS and self.tool not in ("POINT", "TEXT"):
            self.snap_attach = self.cursor.copy()

    def _plane_hit(self, plane, ro, rd):
        """Kilitli düzlemde imleç noktası (v0.25.10). Düzleme kenarından bakılıyorsa (ör.
        üstten bakarken Shift+X → YZ) ışın düzlemi kesmez ya da çok uzakta keser: imleç
        donuyor / fırlıyordu ("Shift+X işe yaramıyor"). O zaman fare, düzlemin başlangıcından
        geçen görünüş düzlemine alınır ve kilitli düzleme izdüşürülür (Blender'daki gibi:
        düzlemin ekranda görünen doğrultusunda hareket)."""
        rdn = rd / max(float(np.linalg.norm(rd)), 1e-15)
        if abs(float(np.dot(rdn, plane.n))) >= 0.15:
            return plane.ray_hit(ro, rd)
        try:
            vp = dm.Plane.from_normal(plane.o, -self._view_dir(), "VIEW",
                                      u_hint=self._view_right())
            h = vp.ray_hit(ro, rd)
        except Exception:
            h = None
        if h is None:
            return plane.ray_hit(ro, rd)
        return h - plane.n * plane.dist(h)

    def _axis_point(self, anchor, i, ro, rd, snap, no_snap):
        """Eksen kilidi (Blender G → X gibi): anchor'dan dünya ekseni i boyunca nokta.
        Yazılan uzunluk eksen boyunca (imleç yönünde; '-' ile ters); yakalanan nokta eksene
        izdüşürülür (kilit bozulmaz); yoksa ızgara adımı."""
        ax = np.zeros(3)
        ax[i] = 1.0
        rdn = rd / max(float(np.linalg.norm(rd)), 1e-15)
        w0 = ro - anchor
        bb = float(np.dot(rdn, ax))
        den = 1.0 - bb * bb
        s = float(np.dot(w0, ax) - bb * np.dot(w0, rdn)) / den if den > 1e-9 else 0.0
        name = "XYZ"[i]
        kind = f"{name} ekseni"
        txt = self.typed[0].strip() if self.typed[0] else ""
        typed = parse_length(txt.lstrip("+-")) if txt else None
        self.snap_kind = self.snap_id = None
        hit = None
        if typed is None and not no_snap:
            mx, my = getattr(self, "mouse", (0.0, 0.0))
            hit = self._lock_curve_hit(mx, my, ("line", anchor, ax))
            if hit is not None and snap is not None and PRIORITY.get(snap[1], 3) <= 1:
                # eksen üstündeki bir uç / orta noktası daha yakınsa o kalır
                q = np.asarray(snap[0], dtype=np.float64)
                on = float(np.linalg.norm(_line_off(q, anchor, ax))) <= \
                    1e-6 * (1.0 + float(np.abs(q).max()))
                qp = self._px(q)
                if on and qp is not None and math.hypot(qp[0] - mx, qp[1] - my) <= hit[1]:
                    hit = None
        if typed is not None:
            s = -typed if txt.startswith("-") else math.copysign(typed, s if s else 1.0)
            kind += " · yazılan"
        elif hit is not None:
            # v0.25.12: eksenin eğriyi kestiği nokta (kilit bozulmaz, eğriye bağlanır)
            s = float(np.dot(hit[0] - anchor, ax))
            kind += " · eğri kesişimi"
            self.info = {"kind": kind, "axis": i}
            self.snap_kind = "Eğri"
            return anchor + ax * s
        elif snap is not None and not no_snap:
            s = float(np.dot(np.asarray(snap[0], dtype=np.float64) - anchor, ax))
            kind += f" · {snap[1]} hizası"
        elif self.grid_on and not no_snap:
            q = anchor + ax * s
            gs = self._grid_step(q)
            g = round(float(q[i]) / gs) * gs - float(anchor[i])
            if abs(g - s) <= GRID_PX * self.ui_scale * self._px_size(q):
                s = g
                kind += " · Izgara"
        self.info = {"kind": kind, "axis": i}
        return anchor + ax * s

    def _temp_plane(self):
        """Geçici zemin açıksa o düzlem (çizim hep bu düzlemde kalır), değilse None."""
        tmp = getattr(self, "temp", None)
        if tmp is None or self.plane_mode != "LOCK" or self.locked is None:
            return None
        return self.locked

    def _on_temp(self, p):
        """Geçici zeminde: eski düzlemdeki bir noktaya yapışıldıysa nokta zemine paralel
        izdüşürülür (çizim yeni yükseklikte başlar / sürer). Asıl nokta snap_src'de kalır."""
        self.snap_src = self.snap_src_id = None
        tp = self._temp_plane()
        if tp is None or p is None:
            return p
        h = tp.dist(p)
        if abs(h) <= 1e-9 * (1.0 + float(np.abs(p).max())):
            return p
        if self.snap_kind is not None:
            self.snap_src = np.asarray(p, dtype=np.float64).copy()
            self.snap_src_id = self.snap_id       # teğet kaynağı için saklanır
            self.snap_id = None                   # farklı yükseklik: çakışık kısıtı yazılmaz
        return p - tp.n * h

    def _arc_continue(self, plane, p, tol, guides=None):
        """İmleç bir tel kafes yayının çemberine yakınsa çember üzerine al (yayın devamı).
        Hiza kılavuzu varsa kılavuzla çemberin kesişimi alınır."""
        best = None
        q = np.asarray(p, dtype=np.float64)
        quv = plane.uv(q)
        for c, R, n in self.refs.arcs:
            if abs(abs(float(np.dot(n, plane.n))) - 1.0) > 1e-3:
                continue
            cuv = plane.uv(c)
            cands = []
            for g, ref in (guides or ()):
                ax = 0 if g == "V" else 1
                o = 1 - ax
                dd = R * R - (ref[ax] - cuv[ax]) ** 2
                if dd < 0:
                    continue
                for sgn in (1.0, -1.0):
                    w = [0.0, 0.0]
                    w[ax] = ref[ax]
                    w[o] = cuv[o] + sgn * math.sqrt(dd)
                    cands.append(tuple(w))
            if not guides:
                v = np.array([quv[0] - cuv[0], quv[1] - cuv[1]])
                d = float(np.linalg.norm(v))
                if d > 1e-12:
                    cands.append((cuv[0] + v[0] / d * R, cuv[1] + v[1] / d * R))
            for w in cands:
                e = math.hypot(w[0] - quv[0], w[1] - quv[1])
                if e <= tol and (best is None or e < best[0]):
                    best = (e, plane.xyz(w) + plane.n * plane.dist(q))
        return None if best is None else best[1]

    def _coord_on(self):
        """Koordinat (X / Y) girişi açık mı (Shift+Tab). Çok tıklamalı şekiller kendi
        ölçülerini kullanır."""
        return bool(getattr(self, "coord_mode", False)) and self.tool not in CLICK_SHAPES

    def _coord_lock(self, plane, anchor, p, dx, dy):
        """Düzlem eksenlerinde: önceki noktaya göre ΔX / ΔY, ilk noktada dünya merkezine
        göre X / Y. Yazılmayan bileşen imleçten alınır."""
        base = plane.uv(anchor) if anchor is not None else plane.uv(np.zeros(3))
        q = plane.uv(p)
        u = base[0] + dx if dx is not None else q[0]
        v = base[1] + dy if dy is not None else q[1]
        h = plane.dist(anchor) if anchor is not None else plane.dist(p)
        return plane.xyz((u, v)) + plane.n * h

    def _apply_locks(self, plane, anchor, p, v0, v1):
        if self._coord_on():
            return self._coord_lock(plane, anchor, p, v0, v1)
        if self.tool == "CIRCLE":
            d = dm.unit(np.asarray(p) - anchor)
            if d is None:
                d = plane.u
            return anchor + d * v0 if v0 is not None else p
        if self.tool == "RECT":
            a, q = plane.uv(anchor), plane.uv(p)
            du, dv = q[0] - a[0], q[1] - a[1]
            if v0 is not None:
                du = math.copysign(v0, du if du else 1.0)
            if v1 is not None:
                dv = math.copysign(v1, dv if dv else 1.0)
            return plane.xyz((a[0] + du, a[1] + dv)) + plane.n * plane.dist(anchor)
        return dm.apply_locks(plane, anchor, p, v0, v1)

    def _make_preview(self, plane):
        self._make_preview_base(plane)
        self._arc_typed(plane)                   # yazılan yarıçap / yay açısı (v0.25.3)

    def _make_preview_base(self, plane):
        self.preview = []
        self.arc_info = None
        anchor = self._anchor()
        cur = self.cursor
        t = self.tool
        if t in CLICK_SHAPES:
            self._shape_preview(plane)
            return
        if t in SHAPE_TOOLS:
            if not self.stage:
                return
            c0 = self.stage[0]
            if np.linalg.norm(cur - c0) < 1e-12:
                return
            if t == "CIRCLE":
                v = cur - c0
                R = float(np.linalg.norm(v - np.dot(v, plane.n) * plane.n))
                if R > 1e-12:
                    self.preview = dm.circle(c0, R, plane)
                    self.arc_info = {"radius": R, "circle": True}
            else:
                self.preview = dm.rectangle(c0, cur, plane)
            return
        if anchor is None:
            return
        if t == "CARC":
            if not self.stage:
                if np.linalg.norm(cur - anchor) > 1e-12:
                    self.preview = [dm.line_seg(anchor, cur)]
                    self.preview[0]["kind"] = "guide"
                return
            arc = dm.center_arc(self.stage[0], anchor, cur, plane.n, self.carc_flip)
            if arc is not None:
                self.preview, self.arc_info = arc["segs"], arc
            return
        if np.linalg.norm(cur - anchor) <= 1e-12:
            return
        if t == "TARC" and self._prev_tangent() is not None:
            arc = dm.tangent_arc(anchor, self._prev_tangent(), cur)
            if arc is not None:
                self.preview, self.arc_info = arc["segs"], arc
                if not self.segs:
                    for sg in self.preview:
                        sg["tan_start"] = True
            else:
                self.preview = [dm.line_seg(anchor, cur)]
        elif t in ("ARC3", "TARC"):
            if not self.stage:
                self.preview = [dm.line_seg(anchor, cur)]
                self.preview[0]["kind"] = "guide"
            else:
                arc = dm.arc_3pt(anchor, cur, self.stage[0])
                if arc is not None:
                    self.preview, self.arc_info = arc["segs"], arc
        elif t == "CV":
            self.preview = dm.bspline_bezier([anchor] + self.stage + [cur])
        elif t == "FIT":
            self.preview = dm.fit_bezier([anchor] + self.stage + [cur])
        elif t == "PEN":
            if self.pen is not None:
                self.preview = [dm.pen_seg(anchor, self.out_h, self.pen["co"], self.pen["h"])]
            else:
                self.preview = [dm.pen_seg(anchor, self.out_h, cur, None)]
        else:
            self.preview = [dm.line_seg(anchor, cur)]

    def _track_update(self, context, mx, my):
        self.mouse = (mx, my)
        tr = self.track
        ro, rd = self._ray(mx, my)
        plane = self._cur_plane() or self.tmp_plane
        if plane is None:
            plane = self._make_plane(self.plane_mode, np.array(context.scene.cursor.location))
            self.tmp_plane = plane
        self.info = None
        self.snap_kind = self.snap_id = None
        if not tr["pts"]:
            snap = None if self.ctrl else self._point_snap(mx, my, ro, rd)
            if snap is not None:
                self.cursor = np.asarray(snap[0], dtype=np.float64)
                self.snap_kind = snap[1]
            else:
                p = plane.ray_hit(ro, rd)
                self.cursor = p if p is not None else plane.o
            self.snap_src = self.snap_src_id = None
            tr["axis"] = None
            self.preview = []
            return
        base = tr["pts"][-1]
        m = np.array([mx, my])
        best = None
        for ax in (plane.u, plane.v, plane.n):
            a = self._px(base)
            b = self._px(base + ax * 50.0 * self.ui_scale * self._px_size(base))
            if a is None or b is None:
                continue
            a, b = np.array(a), np.array(b)
            d = b - a
            L = float(np.linalg.norm(d))
            if L < 1e-6:
                continue
            e = d / L
            v = m - a
            dist = abs(float(e[0] * v[1] - e[1] * v[0]))
            if best is None or dist < best[0]:
                best = (dist, ax)
        ax = best[1] if best is not None else plane.u
        rdn = rd / max(float(np.linalg.norm(rd)), 1e-15)
        w0 = ro - base
        bb = float(np.dot(rdn, ax))
        den = 1.0 - bb * bb
        t = float(bb * np.dot(w0, rdn) - np.dot(w0, ax)) / den if den > 1e-9 else 0.0
        t = -t
        typed = self._signed_len(self.typed[0]) if self.typed[0] else None
        if typed is not None:
            t = math.copysign(abs(typed), t if t != 0 else 1.0) if not \
                self.typed[0].strip().startswith("-") else typed
        elif self.grid_on and not self.ctrl:
            p = base + ax * t
            gs = self._grid_step(p)
            g = round(t / gs) * gs
            if abs(g - t) <= GRID_PX * self.ui_scale * self._px_size(p):
                t = g
        tr["axis"], tr["t"] = ax, t
        self.cursor = self._on_temp(base + ax * t)
        pl = self._cur_plane() or self.tmp_plane
        self._make_preview(pl.moved(self._lock_anchor()) if self._lock_anchor() is not None
                           else pl)

    def _track_event(self, context, event, mx, my, press):
        tr = self.track
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            try:
                self._track_update(context, mx, my)
            except Exception as e:
                print("[Mini CAD] iz güncellenemedi:", e)
            self.area.tag_redraw()
            return {"PASS_THROUGH"}
        if not press:
            return {"RUNNING_MODAL"} if event.type in {"LEFTMOUSE", "RIGHTMOUSE"} else None
        if event.type == "LEFTMOUSE":
            self._track_update(context, mx, my)
            tr["pts"].append(self.cursor.copy())
            self.typed, self.field = ["", ""], 0
            self._status(context, f"İz: {len(tr['pts'])}. nokta · eksen boyunca devam et ya da "
                                  "Enter / sağ tık ile son noktayı kullan")
            self.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if event.type in {"RIGHTMOUSE", "RET", "NUMPAD_ENTER", "SPACE"}:
            if not tr["pts"]:
                self.track = None
                return {"RUNNING_MODAL"}
            final = self.cursor.copy() if self.typed[0] else tr["pts"][-1]
            self.track = None
            self.typed, self.field = ["", ""], 0
            self.cursor = np.asarray(final, dtype=np.float64)
            self.snap_kind = self.snap_id = None
            self.info = None
            pl = self._cur_plane() or self.tmp_plane
            if pl is not None:
                self._make_preview(pl.moved(self._lock_anchor()) if
                                   self._lock_anchor() is not None else pl)
            self._place(context)
            self._status(context, "İz noktası kullanıldı")
            self.area.tag_redraw()
            return {"RUNNING_MODAL"}
        if event.type == "BACK_SPACE":
            if self.typed[0]:
                self.typed[0] = self.typed[0][:-1]
            elif tr["pts"]:
                tr["pts"].pop()
            self._track_update(context, mx, my)
            self.area.tag_redraw()
            return {"RUNNING_MODAL"}
        return None

    def _draw_track2d(self, region):
        tr = self.track
        if tr is None:
            return
        s = self.ui_scale
        pts = [self._px(p) for p in tr["pts"]]
        cur = self._px(self.cursor) if self.cursor is not None else None
        chain = [p for p in pts if p is not None] + ([cur] if cur is not None else [])
        for a, b in zip(chain[:-1], chain[1:]):
            _dashed(a, b, COL_GUIDE, region, dash=8, gap=5)
        for p in pts:
            if p is not None:
                _marker("Kesişim", p[0], p[1], 5 * s, region)
        if cur is not None:
            if tr.get("axis") is not None and tr["pts"]:
                ax = tr["axis"]
                k = int(np.argmax(np.abs(ax)))
                name = "XYZ"[k] if abs(ax[k]) > 0.999 else "Eksen"
                val = self.typed[0] + "_" if self.typed[0] else core.fmt_len(tr.get("t", 0.0))
                txt = f"İz {name}: {val}"
                col = _axis_col(ax)
            else:
                txt = "İz: referans nokta" + (f" ({self.snap_kind})" if self.snap_kind else "")
                col = COL_SNAP
                if self.snap_kind:
                    _marker(self.snap_kind, cur[0], cur[1], 6 * s, region)
            _text(cur[0] + 14 * s, cur[1] + 12 * s, txt, col, int(12 * s))

    def _point_snap_excluding(self, mx, my, ro, rd, own):
        M = np.array(self.rv3d.perspective_matrix, dtype=np.float64)
        P = self.refs.P
        if not len(P):
            return None
        px, ok, _ = _project(P, M, self.region)
        dd = np.where(ok, np.linalg.norm(px - np.array([mx, my]), axis=1), np.inf)
        for i in np.argsort(dd)[:8]:
            if dd[i] > self.radius:
                return None
            if np.linalg.norm(P[i] - own) > 1e-9 and self.refs.kinds[i] in ("Uç", "Merkez",
                                                                               "Orta"):
                return P[i], self.refs.kinds[i]
        return None
